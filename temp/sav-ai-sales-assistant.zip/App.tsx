
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { BusinessInfo, PlanData, PlanLevel } from './types';
import { classifyBusiness, generatePlanPresentation } from './geminiService';
import { fetchPlansFromSheet, fetchSpecificPlan } from './sheetService';
import { FALLBACK_PLANS, INTEGRATIONS_LIST } from './constants';

type Step = 'ignition' | 'booting' | 'intro' | 'classification' | 'plans' | 'details' | 'expert' | 'calculator';

const DEFAULT_GLB_URL = "https://file.pro-talk.ru/tgf/GgMpJwQ9JCkYKglyGHQLJ1MGPTJ2Vxs9JjAnEQc6LxgNYmgDFSJoJjMfDDsZOjs8BBsmCzQ_JHppBnY7ByAOExIjbGYqJTkmVVpuYlYEbAV1VAgQCjEWKxseGVMpKyRYNBcXUm4FNwJgOi4UAQ4SOS4tKzsGCyUuTwJgBHdVAGB-S3U.glb";

const Rivets = () => (
  <>
    <div className="rivet top-2 left-2"></div>
    <div className="rivet top-2 right-2"></div>
    <div className="rivet bottom-2 left-2"></div>
    <div className="rivet bottom-2 right-2"></div>
  </>
);

const App: React.FC = () => {
  const [step, setStep] = useState<Step>('ignition');
  const [inputValue, setInputValue] = useState('');
  const [urlInput, setUrlInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [bootProgress, setBootProgress] = useState(0);
  const [bootStatus, setBootStatus] = useState('Инициализация котлов...');
  const [businessInfo, setBusinessInfo] = useState<BusinessInfo | null>(null);
  const [plans, setPlans] = useState<PlanData[]>([]);
  const [selectedPlan, setSelectedPlan] = useState<PlanLevel | null>(null);
  const [planDetails, setPlanDetails] = useState<{data: PlanData | null, presentation: string} | null>(null);
  const [modelUrl, setModelUrl] = useState<string | null>(null);
  
  const rotationRef = useRef(0);
  const lastXRef = useRef(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const startBooting = useCallback((source: string) => {
    setStep('booting');
    setBootProgress(0);
    setBootStatus('Связь с сервером чертежей...');
    setModelUrl(source);
    
    const modelViewer = document.querySelector('#bg-model') as any;
    if (modelViewer) {
      modelViewer.src = source;
    }
  }, []);

  // Auto-load default model on mount
  useEffect(() => {
    // Small timeout to ensure the DOM is ready for model-viewer selection
    const timer = setTimeout(() => {
      startBooting(DEFAULT_GLB_URL);
    }, 100);
    return () => clearTimeout(timer);
  }, [startBooting]);

  // Unified Model Loading Listener
  useEffect(() => {
    const modelViewer = document.querySelector('#bg-model') as any;
    if (!modelViewer) return;

    const onProgress = (event: any) => {
      const progress = Math.round(event.detail.totalProgress * 100);
      if (step === 'booting') {
        setBootProgress(progress);
        if (progress > 30) setBootStatus('Смазка шестерней...');
        if (progress > 60) setBootStatus('Подача пара...');
        if (progress > 90) setBootStatus('Запуск поршней...');
      }
    };

    const onLoad = () => {
      if (step === 'booting') {
        setBootProgress(100);
        setBootStatus('Механизм запущен!');
        
        const container = document.getElementById('bg-model-container');
        if (container) {
          container.classList.add('active');
        }

        setTimeout(() => {
          setStep('intro');
        }, 1200);
      }
    };

    const onError = (error: any) => {
      if (step === 'booting') {
        console.error("Model Error:", error);
        setBootStatus("Ошибка! Механизм заклинило.");
        // If the default model fails, let user try manual input
        setTimeout(() => setStep('ignition'), 2000);
      }
    };

    modelViewer.addEventListener('progress', onProgress);
    modelViewer.addEventListener('load', onLoad);
    modelViewer.addEventListener('error', onError);

    return () => {
      modelViewer.removeEventListener('progress', onProgress);
      modelViewer.removeEventListener('load', onLoad);
      modelViewer.removeEventListener('error', onError);
    };
  }, [step]);

  // Model Interaction (Drag to rotate)
  useEffect(() => {
    const handleStart = (e: MouseEvent | TouchEvent) => {
      lastXRef.current = 'touches' in e ? (e as TouchEvent).touches[0].clientX : (e as MouseEvent).clientX;
    };

    const handleMove = (e: MouseEvent | TouchEvent) => {
      const currentX = 'touches' in e ? (e as TouchEvent).touches[0].clientX : (e as MouseEvent).clientX;
      const deltaX = currentX - lastXRef.current;
      lastXRef.current = currentX;

      if (step !== 'ignition' && step !== 'booting') {
        rotationRef.current += deltaX * 0.4;
        const bgModel = document.querySelector('#bg-model') as any;
        if (bgModel) {
          bgModel.cameraOrbit = `${rotationRef.current}deg 75deg 105%`;
        }
      }
    };

    window.addEventListener('mousedown', handleStart);
    window.addEventListener('mousemove', handleMove);
    window.addEventListener('touchstart', handleStart, { passive: false });
    window.addEventListener('touchmove', handleMove, { passive: false });

    return () => {
      window.removeEventListener('mousedown', handleStart);
      window.removeEventListener('mousemove', handleMove);
      window.removeEventListener('touchstart', handleStart);
      window.removeEventListener('touchmove', handleMove);
    };
  }, [step]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      startBooting(result);
    };
    reader.readAsDataURL(file);
  };

  const handleUrlLoad = () => {
    if (!urlInput.trim()) return;
    startBooting(urlInput.trim());
  };

  const handleClassify = async () => {
    if (!inputValue.trim()) return;
    setIsLoading(true);
    try {
      const info = await classifyBusiness(inputValue);
      setBusinessInfo(info);
      setStep('classification');
    } catch (err) {
      console.error(err);
      alert('Ошибка давления пара! Попробуйте снова.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleShowPrices = async () => {
    if (!businessInfo) return;
    setIsLoading(true);
    try {
      const sheetPlans = await fetchPlansFromSheet({
        sphere: businessInfo.sphere,
        segment: businessInfo.segment,
        category: businessInfo.category
      });
      setPlans(sheetPlans);
      setStep('plans');
    } catch (err) {
      console.error(err);
      setStep('plans');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectPlan = async (level: PlanLevel) => {
    if (!businessInfo) return;
    setIsLoading(true);
    setSelectedPlan(level);
    try {
      const data = await fetchSpecificPlan({
        sphere: businessInfo.sphere,
        segment: businessInfo.segment,
        category: businessInfo.category,
        package: level
      });
      const presentation = await generatePlanPresentation(businessInfo, level);
      setPlanDetails({ data, presentation });
      setStep('details');
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const renderIgnition = () => (
    <div className="fixed inset-0 bg-[#1A0F0D] flex flex-col items-center justify-center z-[100] p-6 text-center overflow-y-auto">
      <div className="steampunk-border p-8 md:p-12 max-w-lg w-full my-auto">
        <Rivets />
        <div className="mb-8">
          <i className="fa-solid fa-microchip text-7xl text-[#D4AF37] mb-4"></i>
          <h2 className="steampunk-header text-3xl md:text-5xl mb-4">Система SAV AI</h2>
          <p className="text-[#F5F5DC] italic opacity-80 mb-8 font-serif">
            Для активации аналитических модулей необходимо загрузить Механическое Сердце (.glb файл).
          </p>
        </div>
        
        <div className="space-y-6">
          <div className="space-y-3">
             <input 
              type="file" 
              accept=".glb" 
              onChange={handleFileUpload} 
              className="hidden" 
              ref={fileInputRef}
            />
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="steampunk-button w-full py-4 text-lg"
            >
              <i className="fa-solid fa-upload"></i> ВЫБРАТЬ ФАЙЛ
            </button>
          </div>

          <div className="flex items-center gap-4">
            <div className="h-px bg-white opacity-10 flex-1"></div>
            <span className="text-[#D4AF37] text-[10px] italic opacity-40 uppercase tracking-widest">или ссылка</span>
            <div className="h-px bg-white opacity-10 flex-1"></div>
          </div>

          <div className="space-y-3">
            <input 
              type="text"
              placeholder="https://example.com/model.glb"
              className="w-full p-3 bg-black bg-opacity-40 border border-[#D4AF37] border-opacity-30 rounded-xl text-sm outline-none focus:border-opacity-100 transition-all text-[#F5F5DC]"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
            />
            <button 
              onClick={handleUrlLoad}
              className="w-full bg-transparent border border-[#D4AF37] border-opacity-30 text-[#D4AF37] py-3 text-sm hover:bg-[#D4AF37] hover:bg-opacity-10 transition-all rounded-xl uppercase font-bold tracking-widest"
              disabled={!urlInput.trim()}
            >
              <i className="fa-solid fa-link mr-2"></i> Подключить по ссылке
            </button>
          </div>
        </div>
        
        <p className="mt-8 text-[10px] uppercase tracking-[0.3em] opacity-40 text-[#F5F5DC]">
          Требуется формат GLB • Версия 2.0
        </p>
      </div>
    </div>
  );

  const renderBootLoader = () => (
    <div className="fixed inset-0 bg-[#1A0F0D] flex flex-col items-center justify-center z-[100] p-6 text-center">
      <div className="relative mb-12">
        <i className="fa-solid fa-gear text-8xl md:text-9xl text-[#B87333] animate-spin"></i>
        <i className="fa-solid fa-gear text-5xl md:text-6xl text-[#D4AF37] animate-spin absolute -top-6 -right-6" style={{ animationDirection: 'reverse' }}></i>
        <div className="absolute inset-0 flex items-center justify-center text-xl font-bold text-[#F5F5DC] drop-shadow-md">
          {bootProgress}%
        </div>
      </div>
      <h2 className="steampunk-header text-3xl md:text-5xl mb-4 text-[#D4AF37] animate-pulse uppercase tracking-widest">СИНХРОНИЗАЦИЯ</h2>
      <p className="text-[#F5F5DC] italic text-lg md:text-xl tracking-widest opacity-80 mb-8 font-serif">{bootStatus}</p>
      
      <div className="w-full max-w-md h-3 bg-black bg-opacity-40 rounded-full overflow-hidden border border-[#D4AF37] border-opacity-30 p-0.5">
        <div 
          className="h-full bg-gradient-to-r from-[#8B4513] via-[#B87333] to-[#D4AF37] transition-all duration-300 shadow-[0_0_15px_rgba(212,175,55,0.5)]" 
          style={{ width: `${bootProgress}%` }}
        ></div>
      </div>
    </div>
  );

  const renderProcessingLoader = () => (
    <div className="fixed inset-0 bg-black bg-opacity-40 backdrop-blur-md flex flex-col items-center justify-center z-[60]">
      <div className="relative mb-6">
        <i className="fa-solid fa-gear text-6xl text-[#B87333] animate-spin"></i>
        <i className="fa-solid fa-gear text-4xl text-[#D4AF37] animate-spin absolute -top-4 -right-4" style={{ animationDirection: 'reverse' }}></i>
      </div>
      <h2 className="steampunk-header text-2xl text-[#D4AF37] animate-pulse">Обработка данных...</h2>
      <p className="mt-2 text-[#F5F5DC] italic text-sm">Механизмы в движении</p>
    </div>
  );

  if (step === 'ignition') return renderIgnition();
  if (step === 'booting') return renderBootLoader();

  const CALC_URL = `https://docs.google.com/forms/d/e/1FAIpQLSdSARiTa4zYB-sYseymb3Q0C1Y_dBh8oDLavON_2mTu8o574w/viewform?embedded=true&usp=pp_url&entry.2102663603=%D0%A1%D0%B0%D0%B2%D0%B2%D0%B0`;

  return (
    <div className="min-h-screen flex flex-col items-center p-3 md:p-8">
      {isLoading && renderProcessingLoader()}

      {/* Header */}
      <header className="w-full max-w-6xl mb-6 flex justify-between items-center border-b border-white border-opacity-10 pb-4 cursor-pointer" onClick={() => setStep('intro')}>
        <div className="flex items-center gap-3">
          <div className="relative group">
            <div className="w-10 h-10 md:w-14 md:h-14 bg-black bg-opacity-40 backdrop-blur-md rounded-full border border-white border-opacity-20 flex items-center justify-center text-xl md:text-2xl font-black text-[#D4AF37] shadow-lg">
               SAV
            </div>
            <i className="fa-solid fa-gear absolute -bottom-1 -right-1 text-xs md:text-sm text-[#B87333] group-hover:rotate-180 transition-transform duration-1000"></i>
          </div>
          <div>
            <h1 className="text-xl md:text-3xl">ПРОДАВЕЦ</h1>
            <p className="text-[#D4AF37] text-[9px] md:text-[10px] italic tracking-widest uppercase opacity-60">Механический разум для коммерции</p>
          </div>
        </div>
        <div className="hidden sm:block text-right">
          <div className="text-[9px] font-bold opacity-40 uppercase">Манометр ИИ</div>
          <div className="text-[#D4AF37] font-bold opacity-70 text-xs">14.7 PSI</div>
        </div>
      </header>

      <main className="w-full max-w-4xl flex-grow">
        
        {/* STEP 1: INTRO */}
        {step === 'intro' && (
          <div className="steam-fade space-y-5">
            <div className="steampunk-border p-5 md:p-10">
              <Rivets />
              <h2 className="text-2xl md:text-4xl mb-3 text-center sm:text-left">Ваш Запрос в Канцелярию</h2>
              <p className="text-sm md:text-lg leading-relaxed mb-6 italic opacity-80">
                Приветствую! Я ваш механический секретарь SAV AI! 🎩 Опишите род вашей деятельности, 
                и мои шестерни мгновенно определят сегмент и сферу вашего предприятия.
              </p>
              <div className="space-y-5">
                <textarea
                  className="w-full p-4 rounded-xl outline-none transition-all h-28 md:h-32 text-sm md:text-lg shadow-inner"
                  placeholder="Опишите ваше дело... (например: мастерская по починке дирижаблей)"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                />
                <button 
                  onClick={handleClassify}
                  className="steampunk-button w-full py-3.5 text-lg md:text-2xl"
                >
                  <i className="fa-solid fa-gauge-high"></i> Проанализировать
                </button>

                <div className="flex items-center gap-4 py-1">
                  <div className="h-px bg-white opacity-10 flex-1"></div>
                  <span className="text-[#D4AF37] text-[10px] md:text-sm italic opacity-40 uppercase tracking-widest">или воспользуйтесь</span>
                  <div className="h-px bg-white opacity-10 flex-1"></div>
                </div>

                <button 
                  onClick={() => setStep('calculator')}
                  className="w-full bg-transparent border border-white border-opacity-10 text-[#D4AF37] py-2.5 text-base md:text-lg hover:bg-white hover:bg-opacity-5 transition-all flex items-center justify-center gap-2 rounded-xl backdrop-blur-sm"
                >
                  <i className="fa-solid fa-calculator"></i> Калькулятором затрат
                </button>
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: CLASSIFICATION */}
        {step === 'classification' && businessInfo && (
          <div className="steam-fade space-y-5">
            <div className="steampunk-border p-5 md:p-10 relative overflow-hidden">
              <Rivets />
              <div className="absolute top-0 right-0 p-2.5 bg-[#D4AF37] bg-opacity-70 text-black font-bold text-[9px] md:text-[10px] rounded-bl-xl uppercase tracking-tighter">АРХИВ №2025</div>
              
              <div className="mb-6 text-[#F5F5DC] italic leading-relaxed text-xs md:text-base border-l-2 border-[#D4AF37] pl-4 md:pl-6 bg-white bg-opacity-5 py-4 rounded-r-xl">
                {businessInfo.praise}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 md:gap-4 mb-6">
                {['Секция', 'Категория', 'Отрасль'].map((label, i) => {
                    const vals = [businessInfo.segment, businessInfo.category, businessInfo.sphere];
                    return (
                        <div key={i} className="p-2.5 md:p-4 bg-white bg-opacity-5 border border-white border-opacity-5 rounded-xl text-center backdrop-blur-lg">
                            <div className="text-[9px] md:text-[10px] text-[#D4AF37] uppercase mb-1 opacity-50">{label}</div>
                            <div className="text-sm md:text-xl font-bold">{vals[i]}</div>
                        </div>
                    );
                })}
              </div>

              <div className="p-4 md:p-6 bg-white bg-opacity-5 border border-dashed border-[#D4AF37] border-opacity-20 rounded-2xl text-center mb-6">
                <h3 className="text-lg md:text-2xl mb-1.5 text-[#D4AF37]">
                   Индивидуальное решение: {businessInfo.package || 'SAV AI'}
                </h3>
                <p className="text-[10px] md:text-xs italic opacity-50">Механизмы классифицированы. Начинаем расчет цен?</p>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <button 
                  onClick={handleShowPrices}
                  className="steampunk-button flex-1 py-3.5 text-base md:text-xl"
                >
                  <i className="fa-solid fa-scroll"></i> Показать тарифы
                </button>
                <button 
                  onClick={() => setStep('intro')}
                  className="border border-white border-opacity-10 text-[#D4AF37] hover:bg-white hover:bg-opacity-5 py-3 px-6 transition-all text-[11px] md:text-sm uppercase font-bold rounded-xl backdrop-blur-md"
                >
                  Скорректировать
                </button>
              </div>
            </div>
          </div>
        )}

        {/* STEP 3: PLANS GRID */}
        {step === 'plans' && businessInfo && (
          <div className="steam-fade space-y-5">
            <h2 className="text-3xl md:text-5xl text-center mb-8 text-[#D4AF37]">Каталог Решений</h2>
            
            <div className="bg-white bg-opacity-5 backdrop-blur-xl p-3.5 border-l-2 border-[#D4AF37] rounded-r-xl mb-6 italic text-[11px] md:text-sm">
              <p className="opacity-70">Выберите конфигурацию, наиболее пригодную для вашей мануфактуры.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mb-10">
              {(plans.length > 0 ? plans : FALLBACK_PLANS).map((p, idx) => (
                <div 
                  key={idx} 
                  className="steampunk-border p-5 flex flex-col h-full hover:scale-[1.03] transition-transform cursor-pointer group"
                  onClick={() => handleSelectPlan(p.package as PlanLevel)}
                >
                  <Rivets />
                  <div className="text-xl md:text-2xl text-[#D4AF37] mb-3 border-b border-white border-opacity-5 pb-2 font-bold">
                    {p.package}
                  </div>
                  <div className="text-[11px] md:text-xs opacity-60 mb-5 flex-1 whitespace-pre-wrap leading-relaxed">
                    {p.fullDescription?.substring(0, 160)}...
                  </div>
                  <div className="text-xl md:text-3xl font-bold mb-5 text-center text-[#D4AF37] drop-shadow-lg">
                    {p.priceMonth ? `${p.priceMonth} ₽` : 'По запросу'}
                  </div>
                  <button className="steampunk-button w-full py-2.5 text-xs">Изучить чертеж</button>
                </div>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row justify-center gap-3">
                <button 
                  onClick={() => setStep('expert')}
                  className="steampunk-button px-6 md:px-10 py-3.5 text-base md:text-lg"
                >
                   <i className="fa-solid fa-user-gear"></i> Аудит Экспертом
                </button>
                <button 
                  onClick={() => setStep('calculator')}
                  className="border border-white border-opacity-10 text-[#D4AF37] px-6 md:px-10 py-3.5 text-base md:text-lg hover:bg-white hover:bg-opacity-5 transition-all rounded-xl backdrop-blur-md"
                >
                   Точный расчет
                </button>
            </div>
          </div>
        )}

        {/* STEP 4: PLAN DETAILS */}
        {step === 'details' && planDetails && businessInfo && (
          <div className="steam-fade space-y-5 pb-10">
             <div className="steampunk-border p-5 md:p-10">
               <Rivets />
               <div className="flex justify-between items-center mb-6 border-b border-white border-opacity-10 pb-4">
                 <h2 className="text-2xl md:text-5xl text-[#D4AF37]">{selectedPlan}</h2>
                 <button onClick={() => setStep('plans')} className="text-[#D4AF37] underline text-xs md:text-base opacity-60 hover:opacity-100 transition-opacity">К списку</button>
               </div>

               <div className="mb-8">
                  <h3 className="text-lg md:text-xl mb-3 opacity-90 text-[#D4AF37]">Спецификация Механизма:</h3>
                  {planDetails.data?.photoUrl && (
                    <img src={planDetails.data.photoUrl} alt="Plan" className="w-full h-40 md:h-80 object-cover rounded-2xl border border-white border-opacity-10 mb-6 grayscale brightness-90 hover:grayscale-0 transition-all duration-700 shadow-2xl" />
                  )}
                  <div className="bg-white bg-opacity-5 p-4 md:p-6 border border-white border-opacity-5 rounded-2xl whitespace-pre-wrap leading-relaxed text-xs md:text-base italic mb-6 backdrop-blur-2xl">
                    {planDetails.data?.fullDescription || FALLBACK_PLANS.find(p => p.package === selectedPlan)?.fullDescription}
                  </div>
               </div>

               <div className="mb-8">
                  <h3 className="text-lg md:text-xl mb-3 opacity-90 text-[#D4AF37]">Демонстрация Возможностей:</h3>
                  <div className="bg-black bg-opacity-20 p-4 rounded-xl prose prose-invert max-w-none whitespace-pre-wrap leading-relaxed text-[10px] md:text-sm opacity-70">
                    {planDetails.presentation}
                  </div>
               </div>

               <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                 <div className="p-4 md:p-6 bg-white bg-opacity-5 border border-white border-opacity-5 rounded-2xl backdrop-blur-lg">
                    <h4 className="text-[#D4AF37] mb-3 uppercase font-bold text-[10px] md:text-xs opacity-70">Энергоблоки (Токены):</h4>
                    <ul className="space-y-1.5 text-[10px] md:text-xs opacity-60">
                      <li>⚙️ 10 млн. = 600 руб.</li>
                      <li>⚙️ 50 млн. = 3 000 руб.</li>
                      <li>⚙️ 200 млн. = 12 000 руб.</li>
                      <li>⚙️ 400 млн. = 24 000 руб.</li>
                    </ul>
                 </div>
                 <div className="p-4 md:p-6 bg-white bg-opacity-5 border border-white border-opacity-5 rounded-2xl backdrop-blur-lg">
                    <h4 className="text-[#D4AF37] mb-3 uppercase font-bold text-[10px] md:text-xs opacity-70">Узлы Связи:</h4>
                    <div className="h-32 overflow-y-auto text-[9px] md:text-xs space-y-1 pr-2">
                       {INTEGRATIONS_LIST.split('\n').map((line, i) => <div key={i}>{line}</div>)}
                    </div>
                 </div>
               </div>

               <div className="flex flex-col gap-3">
                  <button 
                    onClick={() => setStep('expert')}
                    className="steampunk-button w-full py-4 text-lg md:text-2xl"
                  >
                    Запустить Производство
                  </button>
                  <button 
                    onClick={() => setStep('calculator')}
                    className="border border-white border-opacity-10 text-[#D4AF37] w-full py-3 text-sm md:text-base hover:bg-white hover:bg-opacity-5 transition-all rounded-xl backdrop-blur-md"
                  >
                    Пересчитать на калькуляторе
                  </button>
               </div>
             </div>
          </div>
        )}

        {/* STEP 5: CALCULATOR PAGE */}
        {step === 'calculator' && (
          <div className="steam-fade space-y-5 w-full">
            <div className="flex justify-between items-center border-b border-white border-opacity-10 pb-3 mb-6">
              <h2 className="text-xl md:text-4xl text-[#D4AF37]">Аналитический Блок</h2>
              <button 
                onClick={() => setStep(businessInfo ? 'plans' : 'intro')} 
                className="text-[#D4AF37] underline text-xs md:text-base opacity-70 hover:opacity-100 transition-opacity"
              >
                Вернуться
              </button>
            </div>
            
            <div className="steampunk-border overflow-hidden w-full relative" style={{ minHeight: '550px' }}>
                <Rivets />
                <iframe 
                  src={CALC_URL} 
                  width="100%" 
                  height="1400" 
                  frameBorder="0" 
                  marginHeight={0} 
                  marginWidth={0}
                  className="w-full grayscale brightness-75 hover:grayscale-0 transition-all duration-1000 opacity-80"
                  style={{ background: 'transparent' }}
                  title="Calculator Google Form"
                >
                  Загрузка механизма…
                </iframe>
            </div>
          </div>
        )}

        {/* STEP 6: EXPERT */}
        {step === 'expert' && (
          <div className="steam-fade text-center space-y-6 py-10 md:py-16">
             <div className="relative inline-block p-6 md:p-8 bg-white bg-opacity-5 rounded-full backdrop-blur-2xl border border-white border-opacity-10 shadow-2xl">
                <i className="fa-solid fa-user-tie text-7xl md:text-9xl text-[#D4AF37] drop-shadow-2xl"></i>
                <i className="fa-solid fa-cog gear text-3xl md:text-5xl absolute -bottom-2 -right-2 opacity-30"></i>
             </div>
             <h2 className="text-4xl md:text-6xl text-[#D4AF37]">Сигнал Принят!</h2>
             <p className="text-base md:text-xl max-w-xl mx-auto leading-relaxed italic opacity-70">
               Ваше сообщение доставлено в центральный узел SAV AI. 
               Наш главный механик подготовит чертежи аудита для вашего предприятия в кратчайшие сроки.
             </p>
             <button 
              onClick={() => window.location.reload()}
              className="steampunk-button px-10 md:px-14 py-4 text-base md:text-lg mx-auto"
             >
               Новый Заказ
             </button>
          </div>
        )}

      </main>

      <footer className="mt-8 py-6 text-center opacity-20 text-[8px] md:text-[10px] tracking-[0.3em] uppercase font-bold">
        © 1885-2025 SAV AI Steam-Tech • Королевская Академия Робототехники
      </footer>
    </div>
  );
};

export default App;
